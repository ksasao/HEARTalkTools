-------------------------------------------
HEARTalk UUシリーズ向け応答音声
2017.08.22 @ksasao
-------------------------------------------
■ はじめに
HEARTalk UUシリーズ向けに調整した応答音声です。
ご自由にご利用ください。

下記の動画で利用している応答音声です。
https://twitter.com/ksasao/status/897068857650630656/

HEARTalk で自然な応答システムを作る
http://qiita.com/ksasao/items/e7ca345b3402d41b29d2

も参考にしてください。

■ 利用方法
1. HEARTalk UU-001 または UU-002 を Windows PC に接続します
2. HEARTalk のフォルダに allclr ファイルを Drag & Drop して
   既存の音声を削除します
3. voice フォルダ内のファイルをすべて HEARTalk のフォルダに
   コピーします。

■ 音声の作成手順
音声ファイルは以下のようにして作成しています。ご参考まで。

1. 元となる音声ファイルは、VOICEROID+ 東北きりたん EX を利用して作成しています
  http://www.ah-soft.com/voiceroid/kiritan/
  高さ、話速、抑揚などを調整して、音程なども大まかに設定しています
2. OREMO - UTAUボイスライブラリ作成用音声収録ソフト
  http://nwp8861.web.fc2.com/soft/oremo/
  oremo-english-3.0-b170312.zip
  を利用して、実際の声の高さを確認(Show->Show FO)し、仕様に合わせたファイル名に修正します
  http://uda.la/ht/002.htm
3. Audacity を利用して、音の大きさや長さを微調整します
  http://www.audacityteam.org/

■ 音声ファイルの利用について
音声ファイルは東北きりたんの使用許諾契約書に基づき、無償で配布します。
二次配布などは行わないでください。また、商用利用される場合については、
別途、東北きりたん開発元のAHSの許諾を得る必要があります。
https://www.ah-soft.com/voiceroid/license/


■ お問い合わせ
twitter: @ksasao
mail:    ksasao@gmail.com